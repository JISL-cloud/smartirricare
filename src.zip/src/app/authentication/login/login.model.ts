import { LoginComponent } from "./login.component"

export class Login {
    username: string = "";
    password: string = "";
}