export class CustomError {
    responseStatus = 0;
    message = '';
}
