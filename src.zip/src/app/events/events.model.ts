export class PostEvents{
    startdate:string=""
    endDate:string=""
    fromTime:string="00:00"
    toTime:string="00:00"
    startDateTime:string=""
    endDateTime:string=""
}

export class PostEventsDatalogger{
    gwidNo:number = 0;
    startdate:string=""
    endDate:string=""
    fromTime:string="00:00"
    toTime:string="00:00"
    startDateTime:string=""
    endDateTime:string=""
}