export class MultiDataLogger {
        id: number = 0;
        GwId: number = 0;
        projectId: number = 0;
        dbid: number = 0;
        cmdno: number = 0;
        nwUpid: number = 0;
        maxLengthKb: number = 0;
        frameType: string ="";
        Message: string ="";
        AddedDateTime!: Date ;
    }

    export class GwIdLstMode{
        id: number =0;
        name: number =0; 
    }