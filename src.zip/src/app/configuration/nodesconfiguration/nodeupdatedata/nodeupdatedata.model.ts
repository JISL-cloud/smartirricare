export class NodeUpdateData {
    id: number = 0;
    configSettingUpdateNo: number =0;
    scheduleUpdateNo: number  =0;
    internalMoUpdateNo: number  =0;
    extraByte: number  =0;
    nodeId: number  =0;
}