import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { EventsService } from '../events.service';
import { MultiValveEvent } from '../valveevents/valve.model';
import { MultiNodeJoinDataFrame } from './nodejoindataframe.model';

@Component({
  selector: 'app-nodejoindataframe',
  templateUrl: './nodejoindataframe.component.html',
  styleUrls: ['./nodejoindataframe.component.css']
})
export class NodejoindataframeComponent implements OnInit {
  modelLst: MultiNodeJoinDataFrame[] = [];
  dtOptions:any
  dtTrigger: Subject<any> = new Subject<any>();
  constructor(public valveservice: EventsService, public toastr: ToastrService) { }

  ngOnInit(): void {
    this.dtOptions = {
      retrieve: true,
      pagingType: 'full_numbers',
      pageLength: 10,
      order: [1, 'desc'],
      // columnDefs: [
      //   { "orderable": false, "targets": [0, 5] }

      // ],
      //destroy: true
      stateSave: true,
      dom: 'Bfrtip',
      buttons: [
        'colvis'
      ]

    };
    this.getValveEvets();
  }
  getRtuIdFronNode(nodeid:number){
    return (nodeid & 1023).toString();
  }
  
  getNetworkFronNode(nodeid:number){
    return (nodeid >> 10).toString();
  }
  getEpocTime(time: any) {
    const unixEpochTimeMS = time * 1000;
    const d = new Date(unixEpochTimeMS);    
    return d.toLocaleString();
  }
  getValveEvets() {
    this.valveservice.getMultiNodeJoinDataFrame().subscribe(
      (response: MultiNodeJoinDataFrame[]) => {
        this.modelLst = response;
        this.dtTrigger.next();
      },
      customError => {
        this.toastr.error(
          `Error happened while fetching valve list. <br />
                  ${customError.message}`,
          'Error'
        );
      }
    );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
