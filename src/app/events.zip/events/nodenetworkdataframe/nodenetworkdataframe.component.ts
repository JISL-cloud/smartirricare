import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { EventsService } from '../events.service';
import { MultiValveEvent } from '../valveevents/valve.model';
import { MultiNodeNwDataFrame } from './nodenetworkdataframe.model';

@Component({
  selector: 'app-nodenetworkdataframe',
  templateUrl: './nodenetworkdataframe.component.html',
  styleUrls: ['./nodenetworkdataframe.component.css']
})
export class NodenetworkdataframeComponent implements OnInit {

  modelLst: MultiNodeNwDataFrame[] = [];
  dtOptions: any;
  dtTrigger: Subject<any> = new Subject<any>();
  constructor(public valveservice: EventsService, public toastr: ToastrService) { }

  ngOnInit(): void {
    this.dtOptions = {
      retrieve: true,
      pagingType: 'full_numbers',
      pageLength: 10,
      order: [1, 'desc'],
      // columnDefs: [
      //   { "orderable": false, "targets": [0, 5] }

      // ],
      //destroy: true
      stateSave: true,
      dom: 'Bfrtip',
      buttons: [
        'colvis'
      ]

    };
    this.getValveEvets();
  }

  getRtuIdFronNode(nodeid:number){
    return (nodeid & 1023).toString();
  }
  
  getNetworkFronNode(nodeid:number){
    return (nodeid >> 10).toString();
  }
  getValveEvets() {
    this.valveservice.getNodeNetworkDataFrame().subscribe(
      (response: MultiNodeNwDataFrame[]) => {
        this.modelLst = response;
        this.dtTrigger.next();
      },
      customError => {
        this.toastr.error(
          `Error happened while fetching valve list. <br />
                  ${customError.message}`,
          'Error'
        );
      }
    );
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
}
