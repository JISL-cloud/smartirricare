import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-networkdataanalysis',
  templateUrl: './networkdataanalysis.component.html',
  styleUrls: ['./networkdataanalysis.component.css']
})
export class NetworkdataanalysisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
