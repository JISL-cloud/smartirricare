import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operationalevents',
  templateUrl: './operationalevents.component.html',
  styleUrls: ['./operationalevents.component.css']
})
export class OperationaleventsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
